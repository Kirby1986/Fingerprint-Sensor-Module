#ifndef _IA64REG_
#define _IA64REG_
#if _MSC_VER > 1000
#pragma once
#endif

// Please contact INTEL to get IA64-specific information

#endif // _IA64REG_

