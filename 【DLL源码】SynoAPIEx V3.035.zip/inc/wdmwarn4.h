/*
Include before wdm.h to be able to compile at warning level 4
*/

/*
4214
4201 nonstandard extension using nameless struct/union
4115
4200
4514 unreferenced inline function
**4100 unreferenced formal parameter
4057
*/

#pragma warning(disable:4214 4201 4115 4200 4100 4514 4057 4127)

