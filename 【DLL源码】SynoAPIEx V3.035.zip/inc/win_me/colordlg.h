#include "..\inc16\colordlg.h"
