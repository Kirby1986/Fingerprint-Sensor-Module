/*++

Copyright (c) 1992 - 1995 Microsoft Corporation

Module Name:

    scode.h

Abstract:

    Obsolete SCODE header file.  Use WINERROR.H

--*/

#ifndef  _WINERROR_
#include <winerror.h>
#endif

