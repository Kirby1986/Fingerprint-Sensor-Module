#define rmj		0
#define rmm		23
#define rup		430
#define szVerName	""
#define szVerUser	"OLE2BUILD"
