/* OBSOLETE: Replaced by #define LIB/#include <lzexpand.h> */
#ifndef LIB
#define LIB
#endif
#include <lzexpand.h>
