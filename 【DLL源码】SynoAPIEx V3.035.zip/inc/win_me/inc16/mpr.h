/*****************************************************************/
/**               Microsoft Windows for Workgroups              **/
/**           Copyright (C) Microsoft Corp., 1991-1992          **/
/*****************************************************************/

/* MNR.H -- Definitions for multi-network provider router DLL.
 *
 * History:
 *  03/19/93    lens    Added definitions
 *
 */

#ifndef _INC_NETMPR
#include "..\inc\mpr.h"
#endif /* _INC_NETMPR */
