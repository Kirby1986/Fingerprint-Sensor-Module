/************************************************************************
*                                                                       *
*   drivinit.h -- obsolete                                              *
*                                                                       *
*   Copyright (c) 1985-1994, Microsoft Corp. All rights reserved.       *
*                                                                       *
************************************************************************/
/* OBSOLETE: Use print.h instead */
#include <print.h>
