
#include "stdafx.h"
#include "Device.h"
#include "Protocol.h"
#include "SynoAPI.h"
#include <io.h>
#include <fcntl.h>
#include <winioctl.h>
#include <math.h>

 
#include <objbase.h>
#include <initguid.h>	
#include <setupapi.h>
// requires to link with setupapi.lib
// Link with SetupAPI.Lib.
#pragma comment (lib, "setupapi.lib")

//�����豸.............................
#include "inc\ntddscsi.h"
#include "spti.h" 
#define CMD_READ 0x85
#define CMD_WRITE 0x86
#define CMD_JUDGEDISK 0x87
////////////////////////////////////////////

//#include "usb100.h"
////////////////////////////////////////////////
/////           ���ڲ���                  //////
////////////////////////////////////////////////

 int       g_nComPort     = 0;     //���ں�
 int       g_nBaudRate    = 57600; //������
 HANDLE    g_hCom         = NULL;  //���ھ��
const int   WAITTIME_PER_BYTE =  100;   //��ÿ���ֽ�ʱ��(ms)
extern HANDLE WaitEvent;

 
DEFINE_GUID(GUID_INTERFACE_SILABS_BULK, 
0x76228c66, 0x9584, 0x42d3, 0x96, 0x32, 0xeb, 0xad, 0xa, 0x23, 0xd, 0x13);

							// class CDeviceListEntry

char	m_DeviceName[256]={0};

////////////////////////////////////////////////
///////          ��������                ///////
////////////////////////////////////////////////

int GetDevType(HANDLE hHandle)
{
	if(hHandle==NULL || hHandle==INVALID_HANDLE_VALUE)
		return -1;
	tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;
	return phDevHandle->nDeviceType;
}
int GetDevPacketSize(HANDLE hHandle)
{
	if(hHandle==NULL || hHandle==INVALID_HANDLE_VALUE)
		return -1;
	tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;
	return phDevHandle->nPackSize;
}
int SetDevPacketSize(HANDLE hHandle,int PackSize/*=128*/)
{
	if(hHandle==NULL || hHandle==INVALID_HANDLE_VALUE)
		return -1;
	tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;
	phDevHandle->nPackSize = PackSize;
	return 0;
}
/**********************************************
  FUNCTION:   Delay
  PURPOSE:    ��ʱxx΢��
  ARGS:
         nDelayTime:  ��ʱʱ��(΢��)
  RETURN:
***********************************************/
void WINAPI	Delay(int nDelayTime)
{
	LARGE_INTEGER litmp;
    LONGLONG QPart1,QPart2;


    bool bTimeOut=false;
    double dfFreq;

	QueryPerformanceFrequency(&litmp);// ��ü�������ʱ��Ƶ�� 

    dfFreq = (double) litmp.QuadPart;
	dfFreq = dfFreq/ (1000*1000) ;//////   ��Ƶ�� ת��Ϊ  1us ��  Ƶ����

    QueryPerformanceCounter(&litmp); // ��ó�ʼֵ 
    QPart1 = litmp.QuadPart;

	while(!bTimeOut)
	{
		QueryPerformanceCounter(&litmp); // �����ֵֹ ��
        QPart2 = litmp.QuadPart;

		if (( (double)(QPart2 - QPart1)  ) / dfFreq >nDelayTime)
			bTimeOut=true;////�Ƿ�ʱ
	}
}

/**********************************************
  FUNCTION:   GetByte
  PURPOSE:    �Ӵ��ڶ�һ���ֽ�
  ARGS:
       tranChar�� Ҫ���յ��ֽ�
  RETURN:
       0:    ʧ��
	   1:    �ɹ�
***********************************************/
BOOL WINAPI	GetByte(HANDLE hCom,unsigned char* tranChar)
{
	DWORD    num;
	COMSTAT  comstat;
	DWORD    dwError;
	BOOL     bSuccess;

	if (tranChar == NULL)
		return FALSE;

	if (hCom == NULL)
		return FALSE;

    num = 0;
	*tranChar = 0;

	if ( !ClearCommError(hCom, &dwError, &comstat) )
	{
		return FALSE;
	}

	//��һ���ֽڵ�����
	bSuccess = ReadFile(hCom, tranChar, 1, &num, NULL);
	if( !bSuccess || num!=1 )
	{
		ClearCommError(hCom, &dwError, &comstat);
		return FALSE;
	}

    return TRUE;
}

/**********************************************
  FUNCTION:   SendByte
  PURPOSE:    �򴮿�дһ���ֽ�
  ARGS:
       tranChar�� Ҫ���͵��ֽ�
  RETURN:
       0:    ʧ��
	   1:    �ɹ�
***********************************************/
BOOL WINAPI	SendByte(HANDLE hCom,unsigned char tranChar)
{
    DWORD    num;
	BOOL     bSuccess;

	if (hCom == NULL)
		return FALSE;
//	Delay(120);  //��ʱ120΢��
    
	//����һ���ֽ�
	bSuccess = WriteFile(hCom, &tranChar, 1, &num, NULL);
	if( !bSuccess && num!=1 )
		return FALSE;

    return TRUE;
}

typedef struct _CDeviceListEntry
{								// class CDeviceListEntry
	string	m_linkname;
	string	m_friendlyname;
	string	m_serialnumber;
}CDeviceListEntry;	

#define  IOCTL_CONTROLTRANSFER CTL_CODE(FILE_DEVICE_UNKNOWN,  0x0800+37, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define  IOCTL_BULKTRANDSFER   CTL_CODE(FILE_DEVICE_UNKNOWN,  0x0800+38, METHOD_BUFFERED, FILE_ANY_ACCESS)

struct IOCTRL
{
	BYTE	bDirectionIn;
	UCHAR	bRequest;
    USHORT	wValue;
	USHORT	wIndex;
	ULONG   nPipeNum;
};
CString infostr;
// =========== DeviceApi =================================
typedef struct _BULK_TRANSFER_CONTROL
{
   ULONG pipeNum;
} BULK_TRANSFER_CONTROL, *PBULK_TRANSFER_CONTROL;

typedef struct _VENDOR_REQUEST_IN
{
    BYTE    bRequest;
    WORD    wValue;
    WORD    wIndex;
    WORD    wLength;
    BYTE    direction;
    BYTE    bData[64];
} VENDOR_REQUEST_IN, *PVENDOR_REQUEST_IN;

#define IOCTL_Ezusb_VENDOR_REQUEST   CTL_CODE(FILE_DEVICE_UNKNOWN,0x0800+5,METHOD_BUFFERED,  FILE_ANY_ACCESS)
#define IOCTL_EZUSB_BULK_READ        CTL_CODE(FILE_DEVICE_UNKNOWN,  0x0800+19,METHOD_OUT_DIRECT, FILE_ANY_ACCESS)
static HANDLE hDevice = INVALID_HANDLE_VALUE;

static HANDLE m_hUSBWrite  = INVALID_HANDLE_VALUE;
static HANDLE m_hUSBRead  = INVALID_HANDLE_VALUE;
 
void GetSerialNumber(LPCTSTR DevicePath, std::string* str)
{
	std::string temp = DevicePath;

	temp = temp.substr(temp.find_first_of('#') + 1, temp.find_last_of('#') - temp.find_first_of('#'));
	temp = temp.substr(temp.find_first_of('#') + 1, (temp.find_last_of('#') - temp.find_first_of('#')) - 1);

	if (str)
	{
		*str += temp;
	}
}

#define SILABS_BULK_WRITEPIPE	"PIPE01"
#define SILABS_BULK_READPIPE	"PIPE00" 
/////////////////////////////////////////////////////////////////////////////////////
HANDLE OpenUSBfileEx(char* sDevName,char* sFileName/*=NULL*/)
{
	HANDLE hFile;
//	char sDevNameTmp[256] = {0};
//	strcpy(sDevNameTmp,sDevName);
    if(sFileName)
	{
		strcat (sDevName, "\\");                      
		strcat (sDevName, sFileName);                                      
	}
	hFile = CreateFile(	sDevName,
						GENERIC_WRITE | GENERIC_READ,
						FILE_SHARE_WRITE | FILE_SHARE_READ,
						NULL,
						OPEN_EXISTING,
						0,
						NULL);

	return hFile;
}
int WINAPI OpenUSBEx(HANDLE* pHandle,UINT nDevNum/*=0*/,int PackSize/*=128*/)
{
	UINT uNums = GetUSNDevNums();
	if(uNums==0 || nDevNum>=uNums)
		return -1;//δ�����豸���豸ID������Χ
	HANDLE   hUDisk= INVALID_HANDLE_VALUE;
    tDevHandle* phDevHandle=NULL;
	phDevHandle=new tDevHandle;
	phDevHandle->hDevice=INVALID_HANDLE_VALUE;
	phDevHandle->hUSBRead=INVALID_HANDLE_VALUE;
	phDevHandle->hUSBWrite=INVALID_HANDLE_VALUE;
	phDevHandle->nDeviceType=DEVICE_USB;
	phDevHandle->nPackSize	=PackSize;

	CDeviceListEntry dev;
	// Clear the device info
	dev.m_friendlyname	= "";
	dev.m_linkname		= "";
	dev.m_serialnumber	= "";
    GUID uGUID = GUID_INTERFACE_SILABS_BULK;
	// Retrieve device list for GUID that has been specified.
	HDEVINFO hDevInfoList = SetupDiGetClassDevs (&uGUID, NULL, NULL, (DIGCF_PRESENT | DIGCF_DEVICEINTERFACE)); 
	if (hDevInfoList == NULL)
	{
		delete phDevHandle;
		return -1;
	}
	SP_DEVICE_INTERFACE_DATA deviceInfoData;
	// Clear data structure
	ZeroMemory(&deviceInfoData, sizeof(deviceInfoData));
	deviceInfoData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);
	// retrieves a context structure for a device interface of a device information set.
	if (!SetupDiEnumDeviceInterfaces (hDevInfoList, 0, &uGUID, nDevNum, &deviceInfoData)) 
	{
		delete phDevHandle;
		return -1;
	}
	// Must get the detailed information in two steps
	// First get the length of the detailed information and allocate the buffer
	// retrieves detailed information about a specified device interface.
	PSP_DEVICE_INTERFACE_DETAIL_DATA     functionClassDeviceData = NULL;
	ULONG  predictedLength, requiredLength;

	predictedLength = requiredLength = 0;
	SetupDiGetDeviceInterfaceDetail (	hDevInfoList,
										&deviceInfoData,
										NULL,			// Not yet allocated
										0,				// Set output buffer length to zero 
										&requiredLength,// Find out memory requirement
										NULL);			

	predictedLength = requiredLength;
	functionClassDeviceData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc (predictedLength);
	functionClassDeviceData->cbSize = sizeof (SP_DEVICE_INTERFACE_DETAIL_DATA);
	
	SP_DEVINFO_DATA did = {sizeof(SP_DEVINFO_DATA)};

	// Second, get the detailed information
	if ( SetupDiGetDeviceInterfaceDetail (	hDevInfoList,
											&deviceInfoData,
											functionClassDeviceData,
											predictedLength,
											&requiredLength,
											&did)) 
	{
		TCHAR fname[256];

		// Try by friendly name first.
		if (!SetupDiGetDeviceRegistryProperty(hDevInfoList, &did, SPDRP_FRIENDLYNAME, NULL, (PBYTE) fname, sizeof(fname), NULL))
		{	// Try by device description if friendly name fails.
			if (!SetupDiGetDeviceRegistryProperty(hDevInfoList, &did, SPDRP_DEVICEDESC, NULL, (PBYTE) fname, sizeof(fname), NULL))
			{	// Use the raw path information for linkname and friendlyname
				strncpy(fname, functionClassDeviceData->DevicePath, 256);
			}
		}
			dev.m_friendlyname	= fname;
			dev.m_linkname		= functionClassDeviceData->DevicePath;
			GetSerialNumber(functionClassDeviceData->DevicePath, &(dev.m_serialnumber));
			
		free( functionClassDeviceData );
	}

	// SetupDiDestroyDeviceInfoList() destroys a device information set
	// and frees all associated memory.
	SetupDiDestroyDeviceInfoList (hDevInfoList);
	
	// first set the device by setting the devicename
	char sDevNameTmp[256] = {0};
	strcpy(sDevNameTmp, dev.m_linkname.c_str());
	// next get a handle and return it
	hUDisk = OpenUSBfileEx(sDevNameTmp,NULL);
	if(hUDisk!=INVALID_HANDLE_VALUE)
	{
		phDevHandle->hUSBWrite = OpenUSBfileEx(sDevNameTmp,SILABS_BULK_WRITEPIPE);
		phDevHandle->hUSBRead = OpenUSBfileEx(sDevNameTmp,SILABS_BULK_READPIPE);
	}
	phDevHandle->hDevice = hUDisk;
	*pHandle = (HANDLE)phDevHandle;
	return (hUDisk==INVALID_HANDLE_VALUE ? -1 : 0);
} 
int WINAPI CloseUSBEx(HANDLE hHandle)
{
	if(hHandle==NULL || hHandle==INVALID_HANDLE_VALUE)
		return 1;
	tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;
	if(phDevHandle->hUSBWrite!=NULL && phDevHandle->hUSBWrite!=INVALID_HANDLE_VALUE)
	{
		CloseHandle(phDevHandle->hUSBWrite);
		phDevHandle->hUSBWrite = INVALID_HANDLE_VALUE;
	}
	if(phDevHandle->hUSBRead!=NULL && phDevHandle->hUSBRead!=INVALID_HANDLE_VALUE)
	{
		CloseHandle(phDevHandle->hUSBRead);
		phDevHandle->hUSBRead = INVALID_HANDLE_VALUE;
	}
	if(phDevHandle->hDevice!=NULL && phDevHandle->hDevice!=INVALID_HANDLE_VALUE)
	{
		CloseHandle(phDevHandle->hDevice);
		phDevHandle->hDevice = INVALID_HANDLE_VALUE;
	}
	delete phDevHandle;
 
	return 0;
}
int WINAPI OpenCOMEx(HANDLE* pHandle,int iCom, int iBaud, int PackSize/*=128*/)
{
	CHAR          cCom[10]={0};
	DCB           dcb;
	HANDLE        hCom = INVALID_HANDLE_VALUE;
	BOOL          bSuccess;
	COMSTAT       comStat;
	COMMTIMEOUTS  timeOuts;
	DWORD         dwError;

	if( iCom<1 || iCom>16 )
		return -1;
	int baud = iBaud*9600;

	//����com��
	if( iCom<10 )
		sprintf(cCom,"COM%d",iCom);
	else
		sprintf(cCom,"\\\\.\\COM%d",iCom);
//	cCom[0] = 'C';
//	cCom[1] = 'O';
//	cCom[2] = 'M';
//	cCom[3] = '0'+iCom;
//	cCom[4] = 0;
	
	//��com��
	hCom = CreateFile(cCom,
		GENERIC_WRITE | GENERIC_READ,
		0,
		NULL,
		OPEN_EXISTING,
		0,
		NULL
		);

	if (hCom == INVALID_HANDLE_VALUE)
		return -1;

	PurgeComm(hCom, PURGE_TXABORT|PURGE_RXABORT);
	PurgeComm(hCom, PURGE_TXCLEAR|PURGE_RXCLEAR);

	//����dcb
	bSuccess = GetCommState(hCom, &dcb);
	if (!bSuccess)
	{
		CloseHandle(hCom);
		return -1;
	}

	dcb.BaudRate = (unsigned long) baud;
	dcb.ByteSize = 8;
	dcb.Parity   = 0;
	dcb.StopBits = 2;
	
	bSuccess = SetCommState(hCom, &dcb);
	if (!bSuccess)
	{
		CloseHandle(hCom);
		return -1;
	}

	//���ó�ʱ
	GetCommTimeouts(hCom, &timeOuts);
	timeOuts.ReadTotalTimeoutMultiplier = WAITTIME_PER_BYTE; 
	timeOuts.WriteTotalTimeoutConstant = 100;  
	SetCommTimeouts(hCom,&timeOuts);

	tDevHandle* phDevHandle=NULL;
	phDevHandle=new tDevHandle;
	phDevHandle->hDevice	=hCom;
	phDevHandle->nPackSize	=PackSize;
	phDevHandle->nDeviceType=DEVICE_COM;
	*pHandle = (HANDLE)phDevHandle;

	ClearCommError(hCom,&dwError,&comStat);

	return 0;
}
int WINAPI CloseCOMEx(HANDLE hHandle)
{
	if(hHandle==NULL || hHandle==INVALID_HANDLE_VALUE)
		return 1;
	tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;
	if(phDevHandle->hDevice!=NULL && phDevHandle->hDevice!=INVALID_HANDLE_VALUE)
	{
		CloseHandle(phDevHandle->hDevice);
		phDevHandle->hDevice = INVALID_HANDLE_VALUE;
	}
	delete phDevHandle;
 
	return 0;
}

//�����豸���к� DEVICE_UDisk
GUID  GUIDUsbDevice = {0x53f56307L, 0xb6bf, 0x11D0, {0x94, 0xF2, 0x00, \
0xa0, 0xc9, 0x1e, 0xfb, 0x8b}};
int WINAPI OpenUDiskEx(HANDLE* pHandle,int nDevNum,int PackSize)
{ 	
	if(nDevNum<0)
		return -1;
	HANDLE hUDisk = INVALID_HANDLE_VALUE;
	tDevHandle* phDevHandle=NULL;
	phDevHandle=new tDevHandle;
	phDevHandle->hDevice=INVALID_HANDLE_VALUE;
	phDevHandle->hUSBRead=INVALID_HANDLE_VALUE;
	phDevHandle->hUSBWrite=INVALID_HANDLE_VALUE;
	phDevHandle->nDeviceType=DEVICE_UDisk;
	phDevHandle->nPackSize	=PackSize;

	//-----------��һ��,����ͨ�����ҿ��ƶ��̷����ж��Ƿ�����豸----------------------
    CHAR strDriver[25]; 
	int Driver,iDev=0;
	BYTE SN[13]={0};
	CString strPath;

	//���򿪵�һ���豸ʱ���Ѵ򿪵��豸���к����
	iDev = 0;//�豸������0��ʼ
	for (Driver='C';Driver<='Z';Driver++) 
	{//ѭ�����A��Z 
		strPath.Format("%c:",Driver);
		int type = GetDriveType(strPath); 
		if(type==DRIVE_REMOVABLE || type==DRIVE_CDROM)//���ƶ����ʹ���
		{ 
			sprintf(strDriver,"\\\\.\\%c:",Driver);	
			hUDisk = CreateFile(strDriver,
				GENERIC_WRITE | GENERIC_READ,
				FILE_SHARE_READ | FILE_SHARE_WRITE,
				NULL,
				OPEN_EXISTING,
				0,
				NULL);	
			if(hUDisk==INVALID_HANDLE_VALUE)
				continue;
			if(JudgeDisk(hUDisk)==PS_OK)
			{
				if(nDevNum==iDev)//............�ɹ�! ������Ϣ��Ȼ�󷵻�
				{
					phDevHandle->hDevice = hUDisk;
					*pHandle = (HANDLE)phDevHandle;
					return (hUDisk==INVALID_HANDLE_VALUE ? -1 : 0);
				}
				else
					iDev++;
			}
			CloseHandle(hUDisk);
			hUDisk= INVALID_HANDLE_VALUE;
		} 	
	}
	
	//----------�ڶ���,������������̷��������ǵ�U��,�����Ƿ���U�̲���-----------
	//---����Ĵ���ᵼ�²�������ɾ��U��-----------
	iDev = 0;
	//�õ���������u���豸����豸�б�
    HDEVINFO hDevInfo = SetupDiGetClassDevs(&GUIDUsbDevice, NULL, NULL,(DIGCF_PRESENT | DIGCF_INTERFACEDEVICE)); 
	if(!hDevInfo)
		return -1;
    SP_INTERFACE_DEVICE_DATA DevInfoData;
    DevInfoData.cbSize = sizeof (SP_INTERFACE_DEVICE_DATA);
    int DeviceNo = 0;
    SetLastError(NO_ERROR);
    while(GetLastError() != ERROR_NO_MORE_ITEMS)
    {
		// �оٳ�Ա�豸������������Ϣ
        if(SetupDiEnumInterfaceDevice (hDevInfo,0, &GUIDUsbDevice,DeviceNo,&DevInfoData))
        {
            // get details about this device
            ULONG  DevDetailLen = 0;
            SetupDiGetInterfaceDeviceDetail(hDevInfo,&DevInfoData,NULL, 0,&DevDetailLen,NULL); // not interested in the specific dev-node
            PSP_INTERFACE_DEVICE_DETAIL_DATA pDevDetail = (SP_INTERFACE_DEVICE_DETAIL_DATA*)malloc(DevDetailLen);
            pDevDetail->cbSize = sizeof(SP_INTERFACE_DEVICE_DETAIL_DATA);
            if(! SetupDiGetInterfaceDeviceDetail(hDevInfo,&DevInfoData,pDevDetail,DevDetailLen,NULL,NULL)) 
			{
			//	HidD_GetAttributes()
				free(pDevDetail);
				SetupDiDestroyDeviceInfoList(hDevInfo);
				return -1;
			}
            // open a file to this device		
			hUDisk = CreateFile(pDevDetail->DevicePath,
				GENERIC_READ | GENERIC_WRITE,
				FILE_SHARE_READ | FILE_SHARE_WRITE,
				NULL, // no SECURITY_ATTRIBUTES structure
				OPEN_EXISTING, // No special create flags
				0, // to allow access to USB interrupt reports
				NULL); // No template file
            free(pDevDetail);
			++DeviceNo;//�����һ���豸.
			if(JudgeDisk(hUDisk)==PS_OK)//�����ǵ�U��.
			{
				if(nDevNum==iDev)//............�ɹ�! ������Ϣ��Ȼ�󷵻�
				{
					phDevHandle->hDevice = hUDisk;
					*pHandle = (HANDLE)phDevHandle;
					SetupDiDestroyDeviceInfoList(hDevInfo);
					return (hUDisk==INVALID_HANDLE_VALUE ? -1 : 0);
				}
				else
					iDev++;
			}				 
			CloseHandle(hUDisk);
			hUDisk=INVALID_HANDLE_VALUE;
        }
	} 
    SetupDiDestroyDeviceInfoList(hDevInfo);//*/
	return -1; 	
}
int WINAPI CloseUDiskEx(HANDLE hHandle)
{
	if(hHandle==NULL || hHandle==INVALID_HANDLE_VALUE)
		return 1;
	tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;
	if(phDevHandle->hDevice!=NULL && phDevHandle->hDevice!=INVALID_HANDLE_VALUE)
	{
		CloseHandle(phDevHandle->hDevice);
		phDevHandle->hDevice = INVALID_HANDLE_VALUE;
	}
	delete phDevHandle;
 
	return 0;
}
int JudgeDisk(HANDLE hUDev)
{
    BYTE pData[32];
	BOOL status = 0;  
	
    SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER sptdwb;
    ULONG length = 0,           
		returned = 0,
		sectorSize = 512;
	if (hUDev == INVALID_HANDLE_VALUE) 
		return -1;
	ULONG TransLen=0;
    ZeroMemory(&sptdwb, sizeof(SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER));     
	
    sptdwb.sptd.Length = sizeof(SCSI_PASS_THROUGH_DIRECT);
    sptdwb.sptd.PathId = 0;
    sptdwb.sptd.TargetId = 1;
    sptdwb.sptd.Lun = 0;
    sptdwb.sptd.CdbLength = CDB10GENERIC_LENGTH;
    sptdwb.sptd.SenseInfoLength = 0;
    sptdwb.sptd.DataIn = SCSI_IOCTL_DATA_IN;
    sptdwb.sptd.DataTransferLength = 2;
    sptdwb.sptd.TimeOutValue = 2000;
    sptdwb.sptd.DataBuffer = pData;
    sptdwb.sptd.SenseInfoOffset =
		offsetof(SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER,ucSenseBuf);
    sptdwb.sptd.Cdb[0] = CMD_JUDGEDISK;    

    length = sizeof(SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER);
    status = DeviceIoControl(hUDev,
		IOCTL_SCSI_PASS_THROUGH_DIRECT,
		&sptdwb,
		length,
		&sptdwb,
		length,
		&returned,
		FALSE);	 
	if(!status)
	  return PS_COMM_ERR;
	if(pData[0]!=0x55 || pData[1]!=0x33)
		return PS_COMM_ERR;
	return PS_OK;
}

int WINAPI OpenDeviceEx(HANDLE* pHandle, int nDeviceType,int iCom,int iBaud,int nPackageSize/*=2*/,int iDevNum/*=0*/)
{
	int iPackSize = 32*(0x1<<nPackageSize);
	if(nDeviceType==DEVICE_USB)			// USB	(0)
		return OpenUSBEx(pHandle,iDevNum,iPackSize);
	else if(nDeviceType==DEVICE_COM)	// COM	(1)
		return OpenCOMEx(pHandle,iCom,iBaud,iPackSize);
	else if(nDeviceType==DEVICE_UDisk)	//UDisk	(2)
		return OpenUDiskEx(pHandle,iDevNum,iPackSize);
	else
		return -1;
}
int WINAPI CloseDeviceEx(HANDLE hHandle)
{
	if(hHandle==NULL || hHandle==INVALID_HANDLE_VALUE)
		return 1;
	tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;
	int iDevType = phDevHandle->nDeviceType;//�豸����
	if( iDevType==DEVICE_USB )			// USB	(0)
		return CloseUSBEx(hHandle);
	else if( iDevType==DEVICE_COM )		// COM	(1)
		return CloseCOMEx(hHandle);
	else if( iDevType==DEVICE_UDisk )	//UDisk	(2)
		return CloseUDiskEx(hHandle);
	else
		return -1;
}

//////////////////////////////////////////////////////////////////////////////////////
int USBGetData(HANDLE hHandle,unsigned char* DataBuf,int nLen,int  timeout)
{
    OVERLAPPED lp;
	lp.Offset = 0;
	lp.OffsetHigh = 0;
	lp.hEvent = WaitEvent;
	DWORD nSent = 0;	
	DWORD nBytesReceived = 2;
    	
	VENDOR_REQUEST_IN VenderRequest;
	VenderRequest.bRequest = 1; 
	VenderRequest.direction= 1;
	VenderRequest.wLength = 2;
	VenderRequest.wValue =nLen;
	BYTE buf[10];

	 tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;

	ResetEvent(WaitEvent);

	if ( !DeviceIoControl(phDevHandle->hDevice, IOCTL_Ezusb_VENDOR_REQUEST, &VenderRequest, sizeof(VenderRequest), buf, 
			sizeof(buf), &nBytesReceived,&lp) )
	{
        while (WaitForSingleObject(WaitEvent,timeout))
        {	
			//CloseUSBEx(hHandle);
			return -4;
        }		
	}
//	Sleep(DELAY_TIME);
    return DeviceRead(phDevHandle->hUSBRead,DataBuf,nLen,&nBytesReceived);
 
	return 0;	
}
 
int USBDownData(HANDLE hHandle,unsigned char *image,int nLen)
{
    OVERLAPPED lp;
	lp.Offset = 0;
	lp.OffsetHigh = 0;
	lp.hEvent = WaitEvent;
	
	DWORD nSent = 0;
	DWORD nBytesReceived = 2;
	VENDOR_REQUEST_IN VenderRequest;
	VenderRequest.bRequest = 0;
	VenderRequest.direction= 1;
	VenderRequest.wValue=nLen;
	VenderRequest.wLength = 2;
	BYTE buf[10];
 
	tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;

	int times=0;
//REDO:
	ResetEvent(WaitEvent);	
	if ( !DeviceIoControl(phDevHandle->hDevice, IOCTL_Ezusb_VENDOR_REQUEST, &VenderRequest, sizeof(VenderRequest), buf, 
			sizeof(buf), &nBytesReceived,&lp) )
	{
		while (WaitForSingleObject(WaitEvent,PS_MAXWAITTIME))
		{
			CloseUSBEx(hHandle);
			return -4;
		}
	}
//   Sleep(DELAY_TIME);
    DWORD lWriteByte=nLen;
	return DeviceWrite(phDevHandle->hUSBWrite,image,nLen,&lWriteByte);
    //Sleep(100);
    
	return 0;	
}

int USBDownData1(HANDLE hHandle,unsigned char *image,int nLen)
{
    OVERLAPPED lp;
	lp.Offset = 0;
	lp.OffsetHigh = 0;
	lp.hEvent = WaitEvent;
	DWORD nSent = 0;
	DWORD nBytesReceived = 0;
	
	VENDOR_REQUEST_IN VenderRequest;
	VenderRequest.bRequest = 1;//��DownData���������� ֻ�������������õ�
	VenderRequest.direction= 1;
	VenderRequest.wValue=nLen;
	VenderRequest.wLength = 2;
	BYTE buf[10];

	tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;

	int times=0;
//REDO:
    ResetEvent(WaitEvent);		
	if ( !DeviceIoControl(phDevHandle->hDevice, IOCTL_Ezusb_VENDOR_REQUEST, &VenderRequest, sizeof(VenderRequest), buf, 
			sizeof(buf), &nBytesReceived,&lp) )
	{
		while (WaitForSingleObject(WaitEvent,PS_MAXWAITTIME))
		{
		//	CloseUSBEx(hHandle);
			return -4;
		}
	}
//	Sleep(DELAY_TIME);
    DWORD lWriteByte=nLen;
	return DeviceWrite(phDevHandle->hUSBWrite,image,nLen,&lWriteByte);

	return 0;	
}

int USBGetImage(HANDLE hHandle,unsigned char* DataBuf,int nLen)
{
    OVERLAPPED lp;
	lp.Offset = 0;
	lp.OffsetHigh = 0;
	lp.hEvent = WaitEvent;

	DWORD nSent = 0;
	DWORD nBytesReceived = 0;
	VENDOR_REQUEST_IN VenderRequest;
	VenderRequest.bRequest = 1;
	VenderRequest.direction= 1;
	VenderRequest.wLength = 2;
	VenderRequest.wValue =nLen;
	BYTE buf[10];

	tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;

//	clock_t start, finish;
//	start = clock();
	ResetEvent(WaitEvent);
	if ( !DeviceIoControl(phDevHandle->hDevice, IOCTL_Ezusb_VENDOR_REQUEST, &VenderRequest, sizeof(VenderRequest), buf, 
			sizeof(buf), &nBytesReceived,&lp) )
	{
		while (WaitForSingleObject(WaitEvent,PS_MAXWAITTIME))
		{
		//	CloseUSBEx(hHandle);
			return -4;
		}
	}
    
	nBytesReceived = nLen/2;
    BYTE* pDataStorePos = DataBuf;
//    Sleep(DELAY_TIME);

	if(DeviceRead(phDevHandle->hUSBRead,pDataStorePos,nLen/2,&nBytesReceived))
		return -1;

    nBytesReceived = nLen/2;
    pDataStorePos = DataBuf+nLen/2;
    //Sleep(DELAY_TIME);
	return DeviceRead(phDevHandle->hUSBRead,pDataStorePos,nLen/2,&nBytesReceived);
 
	return 0;	
}

int USBDownImage(HANDLE hHandle,unsigned char *image,int nLen)
{
    OVERLAPPED lp;
	lp.Offset = 0;
	lp.OffsetHigh = 0;
	lp.hEvent = WaitEvent;	
 
	DWORD nSent = 0;
	DWORD nBytesReceived = 0;
	VENDOR_REQUEST_IN VenderRequest;
	VenderRequest.bRequest = 1;
	VenderRequest.direction= 1;
	VenderRequest.wValue=nLen;
	VenderRequest.wLength = 2;
	BYTE buf[10];
 
	tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;

	int times=0;
//REDO:
    ResetEvent(WaitEvent);		
	if ( !DeviceIoControl(phDevHandle->hDevice, IOCTL_Ezusb_VENDOR_REQUEST, &VenderRequest, sizeof(VenderRequest), buf, 
			sizeof(buf), &nBytesReceived,&lp) )
	{
		while (WaitForSingleObject(WaitEvent,PS_MAXWAITTIME))
		{
			//CloseUSBEx(hHandle);
			return -4;
		}
	}
//    Sleep(DELAY_TIME);
    
	nBytesReceived = 0;
    BYTE* pDataStorePos = image;

	if(DeviceWrite(phDevHandle->hUSBWrite,pDataStorePos,nLen/4,&nBytesReceived))
		return -1;

	nBytesReceived = 0;
    pDataStorePos = image+nLen/4;
	if(DeviceWrite(phDevHandle->hUSBWrite,pDataStorePos,nLen/4,&nBytesReceived))
		return -1;

    nBytesReceived = 0;
    pDataStorePos = image+nLen*2/4;	
	if(DeviceWrite(phDevHandle->hUSBWrite,pDataStorePos,nLen/4,&nBytesReceived))
		return -1;

	nBytesReceived = 0;
    pDataStorePos = image+nLen*3/4;	
	return DeviceWrite(phDevHandle->hUSBWrite,pDataStorePos,nLen/4,&nBytesReceived);

	return 0;	
}

//read device
int DeviceRead(HANDLE hUSBRead,BYTE* buffer, DWORD dwSize, DWORD* lpdwBytesRead)
{
	int	status = 0;
	status = F32x_Read(hUSBRead, buffer, dwSize, lpdwBytesRead);
	return status;	
}

//write device
int DeviceWrite(HANDLE hUSBWrite,BYTE* buffer, DWORD dwSize, DWORD* lpdwBytesWritten)
{
	int	status	= 0;	
	status = F32x_Write(hUSBWrite, buffer, dwSize, lpdwBytesWritten);	
	return status;
}

int F32x_Write(HANDLE cyHandle, LPVOID lpBuffer, DWORD dwBytesToWrite, LPDWORD lpdwBytesWritten)
{
	int	status = F32x_INVALID_HANDLE;
	
	// Validate parameters
	if (!ValidParam(lpBuffer, lpdwBytesWritten))
	{
		return F32x_INVALID_PARAMETER;
	}
	
	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		if ((dwBytesToWrite > 0) && (dwBytesToWrite <= F32x_MAX_WRITE_SIZE))
		{
			if (!WriteFile(cyHandle, lpBuffer, dwBytesToWrite, lpdwBytesWritten, NULL))
			{
				status = F32x_WRITE_ERROR;		
				if (sgdwWriteTimeout > 0)
				{
					DWORD	dwStart	= GetTickCount();
					DWORD	dwEnd	= GetTickCount();
					
					// Keep trying to write until success or timeout
					while((dwEnd - dwStart) < sgdwWriteTimeout && status != F32x_SUCCESS)
					{
						if (WriteFile(cyHandle, lpBuffer, dwBytesToWrite, lpdwBytesWritten, NULL))
						{
							status = F32x_SUCCESS;	// Write succeeded after > 1 attempts.
						}						
						dwEnd = GetTickCount();
					}
				}
			}
			else
				status = F32x_SUCCESS;				// Write succeeded on first attempt.
		}
		else
			status = F32x_INVALID_REQUEST_LENGTH;
	}
	
	return status;
}

int F32x_Read(HANDLE cyHandle, LPVOID lpBuffer, DWORD dwBytesToRead, LPDWORD lpdwBytesReturned)
{

	int	status = 0;

	// Validate parameters
	if (!ValidParam(lpBuffer, lpdwBytesReturned))
	{
		return F32x_INVALID_PARAMETER;
	}

	// Check for a valid Handle value
	if (cyHandle != INVALID_HANDLE_VALUE)
	{
		// Check that the read length is within range
		if ((dwBytesToRead > 0) && (dwBytesToRead <= F32x_MAX_READ_SIZE))
		{
			// Read transfer packet
			int icount=0;
			while(!ReadFile(cyHandle, lpBuffer, dwBytesToRead, lpdwBytesReturned, NULL))
			{	// Device IO failed.
				 if (icount++ > 10)
				 {
					status = F32x_TIME_OUT;	
					break;
				 }
			} 
		}
		else
			status = F32x_INVALID_REQUEST_LENGTH;
	}
	else 
		status = F32x_INVALID_HANDLE;

	return status;
}

//------------------------------------------------------------------------
// ValidParam(LPDWORD)
//
// Checks validity of an LPDWORD pointer value.
//------------------------------------------------------------------------
static BOOL ValidParam(LPDWORD lpdwPointer)
{
	DWORD temp = 0;
	
	try 
	{
		temp = *lpdwPointer;
	}
	catch(...)
	{
		return FALSE;
	}
	return TRUE;
}


//------------------------------------------------------------------------
// ValidParam(LPVOID)
//
// Checks validity of an LPVOID pointer value.
//------------------------------------------------------------------------

static BOOL ValidParam(LPVOID lpVoidPointer)
{
	BYTE temp = 0;
	
	try 
	{
		temp = *((BYTE*)lpVoidPointer);
	}
	catch(...)
	{
		return FALSE;
	}
	return TRUE;
}


//------------------------------------------------------------------------
// ValidParam(HANDLE*)
//
// Checks validity of an HANDLE* pointer value.
//------------------------------------------------------------------------
static BOOL ValidParam(HANDLE* lpHandle)
{
	HANDLE temp = 0;
	
	try 
	{
		temp = *lpHandle;
	}
	catch(...)
	{
		return FALSE;
	}
	return TRUE;
}


//------------------------------------------------------------------------
// ValidParam(LPVOID, LPDWORD)
//
// Checks validity of LPVOID, LPDWORD pair of pointer values.
//------------------------------------------------------------------------
static BOOL ValidParam(LPVOID lpVoidPointer, LPDWORD lpdwPointer)
{
	if (ValidParam(lpVoidPointer))
		if (ValidParam(lpdwPointer))
			return TRUE;
	return FALSE;
}


//------------------------------------------------------------------------
// ValidParam(LPDWORD, LPDWORD)
//
// Checks validity of LPDWORD, LPDWORD pair of pointer values.
//------------------------------------------------------------------------
static BOOL ValidParam(LPDWORD lpdwPointer1, LPDWORD lpdwPointer2)
{
	if (ValidParam(lpdwPointer1))
		if (ValidParam(lpdwPointer2))
			return TRUE;
	return FALSE;
}


DWORD GetUSNDevNums()
{
	DWORD numDevices = 0;

	GUID nGUID = GUID_INTERFACE_SILABS_BULK;
	// Retrieve device list for GUID that has been specified.
	HDEVINFO hDevInfoList = SetupDiGetClassDevs (&nGUID, NULL, NULL, (DIGCF_PRESENT | DIGCF_DEVICEINTERFACE)); 

	if (hDevInfoList != NULL)
	{
		SP_DEVICE_INTERFACE_DATA deviceInfoData;

		for (int index = 0; index < 127;index++)
		{
			// Clear data structure
			ZeroMemory(&deviceInfoData, sizeof(deviceInfoData));
			deviceInfoData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);

			// retrieves a context structure for a device interface of a device information set.
			if (SetupDiEnumDeviceInterfaces (hDevInfoList, 0, &nGUID, index, &deviceInfoData)) 
			{
				numDevices++;
			}
			else
			{
				if ( GetLastError() == ERROR_NO_MORE_ITEMS ) 
					break;
			}
		}
	}

	// SetupDiDestroyDeviceInfoList() destroys a device information set
	// and frees all associated memory.
	SetupDiDestroyDeviceInfoList (hDevInfoList);

	return numDevices;
}

DWORD GetUDiskNums()	//use for UDisk	; UDisk  �豸��
{ 	
	HANDLE hUDisk = INVALID_HANDLE_VALUE;
	DWORD numDevices = 0;

	//-----------��һ��,����ͨ�����ҿ��ƶ��̷����ж��Ƿ�����豸----------------------
    CHAR strDriver[25]; 
	int Driver,iDev=0;
	BYTE SN[13]={0};
	CString strPath;

	//���򿪵�һ���豸ʱ���Ѵ򿪵��豸���к����
	for (Driver='C';Driver<='Z';Driver++) 
	{//ѭ�����A��Z 
		strPath.Format("%c:",Driver);
		int type = GetDriveType(strPath); 
		if(type==DRIVE_REMOVABLE || type==DRIVE_CDROM)//���ƶ����ʹ���
		{ 
			sprintf(strDriver,"\\\\.\\%c:",Driver);	
			hUDisk = CreateFile(strDriver,
				GENERIC_WRITE | GENERIC_READ,
				FILE_SHARE_READ | FILE_SHARE_WRITE,
				NULL,
				OPEN_EXISTING,
				0,
				NULL);	
			if(hUDisk==INVALID_HANDLE_VALUE)
				continue;
			if(JudgeDisk(hUDisk)==PS_OK)
				numDevices++;//�豸����1
			CloseHandle(hUDisk);
			hUDisk= INVALID_HANDLE_VALUE;
		} 	
	}
	
	//----------�ڶ���,������������̷��������ǵ�U��,�����Ƿ���U�̲���-----------
	//---����Ĵ���ᵼ�²�������ɾ��U��-----------
	//�õ���������u���豸����豸�б�
    HDEVINFO hDevInfo = SetupDiGetClassDevs(&GUIDUsbDevice, NULL, NULL,(DIGCF_PRESENT | DIGCF_INTERFACEDEVICE)); 
	if(!hDevInfo)
		return numDevices;
    SP_INTERFACE_DEVICE_DATA DevInfoData;
    DevInfoData.cbSize = sizeof (SP_INTERFACE_DEVICE_DATA);
    int DeviceNo = 0;
    SetLastError(NO_ERROR);
    while(GetLastError() != ERROR_NO_MORE_ITEMS)
    {
		// �оٳ�Ա�豸������������Ϣ
        if(SetupDiEnumInterfaceDevice (hDevInfo,0, &GUIDUsbDevice,DeviceNo,&DevInfoData))
        {
            // get details about this device
            ULONG  DevDetailLen = 0;
            SetupDiGetInterfaceDeviceDetail(hDevInfo,&DevInfoData,NULL, 0,&DevDetailLen,NULL); // not interested in the specific dev-node
            PSP_INTERFACE_DEVICE_DETAIL_DATA pDevDetail = (SP_INTERFACE_DEVICE_DETAIL_DATA*)malloc(DevDetailLen);
            pDevDetail->cbSize = sizeof(SP_INTERFACE_DEVICE_DETAIL_DATA);
            if(! SetupDiGetInterfaceDeviceDetail(hDevInfo,&DevInfoData,pDevDetail,DevDetailLen,NULL,NULL)) 
			{
			//	HidD_GetAttributes()
				free(pDevDetail);
				SetupDiDestroyDeviceInfoList(hDevInfo);
				return numDevices;
			}
            // open a file to this device		
			hUDisk = CreateFile(pDevDetail->DevicePath,
				GENERIC_READ | GENERIC_WRITE,
				FILE_SHARE_READ | FILE_SHARE_WRITE,
				NULL, // no SECURITY_ATTRIBUTES structure
				OPEN_EXISTING, // No special create flags
				0, // to allow access to USB interrupt reports
				NULL); // No template file
            free(pDevDetail);
			++DeviceNo;//�����һ���豸.
			if(JudgeDisk(hUDisk)==PS_OK)//�����ǵ�U��.
				numDevices++;				 
			CloseHandle(hUDisk);
			hUDisk=INVALID_HANDLE_VALUE;
        }
	} 
    SetupDiDestroyDeviceInfoList(hDevInfo);//*/
	return numDevices; 	
}

//UDiskͨѶ
int UDiskSendData(HANDLE hHandle, BYTE* pData,ULONG nLength,INT nTimeOut/*=2000*/)
{//PS_COMM_ERR	PS_OK
	BOOL status = 0; 
    SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER sptdwb;
    ULONG length = 0,           
		returned = 0,
		sectorSize = 512;
	if (hHandle == INVALID_HANDLE_VALUE) 
		return PS_COMM_ERR;

	if(nTimeOut<2000)
		nTimeOut = 2000;
	tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;
	HANDLE hUDisk = phDevHandle->hDevice;

	ULONG TransLen=nLength;
    ZeroMemory(&sptdwb, sizeof(SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER));     
    sptdwb.sptd.Length  = sizeof(SCSI_PASS_THROUGH_DIRECT);
    sptdwb.sptd.PathId  = 0;
    sptdwb.sptd.TargetId= 1;
    sptdwb.sptd.Lun	    = 0;
    sptdwb.sptd.CdbLength	= CDB10GENERIC_LENGTH;
    sptdwb.sptd.SenseInfoLength = 0;
    sptdwb.sptd.DataIn	= SCSI_IOCTL_DATA_OUT;
    sptdwb.sptd.DataTransferLength = TransLen;
    sptdwb.sptd.TimeOutValue	= nTimeOut;
    sptdwb.sptd.DataBuffer		= pData;
    sptdwb.sptd.SenseInfoOffset = offsetof(SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER,ucSenseBuf);
    sptdwb.sptd.Cdb[0] = CMD_WRITE;    

    length = sizeof(SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER);
    status = DeviceIoControl(hUDisk,
		IOCTL_SCSI_PASS_THROUGH_DIRECT,
		&sptdwb,
		length,
		&sptdwb,
		length,
		&returned,
		FALSE);//1-OK	 
	if(status)
		return PS_OK;
	return PS_COMM_ERR;
}
int UDiskRevData(HANDLE hHandle, BYTE* pData,ULONG* pnLength,INT nTimeout/*=2000*/)
{
	BOOL status = 0;  
    SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER sptdwb;
    ULONG length = 0,           
		returned = 0,
		sectorSize = 512;
	ULONG TransLen;
	if(nTimeout<2000)
		nTimeout = 2000;
	if (hHandle == INVALID_HANDLE_VALUE) 
		return PS_COMM_ERR;

	tDevHandle* phDevHandle;
	phDevHandle=(tDevHandle*)hHandle;
	HANDLE hUDisk = phDevHandle->hDevice;
	
    ZeroMemory(&sptdwb, sizeof(SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER));      	
	TransLen=*pnLength;	
    if(TransLen==1) 
		TransLen=2;
    sptdwb.sptd.Length		= sizeof(SCSI_PASS_THROUGH_DIRECT);
    sptdwb.sptd.PathId		= 0;
    sptdwb.sptd.TargetId	= 1;
    sptdwb.sptd.Lun			= 0;
    sptdwb.sptd.CdbLength	= CDB10GENERIC_LENGTH;
    sptdwb.sptd.SenseInfoLength = 0;
    sptdwb.sptd.DataIn			= SCSI_IOCTL_DATA_IN;
    sptdwb.sptd.DataTransferLength =TransLen;	
    sptdwb.sptd.TimeOutValue	= nTimeout;
    sptdwb.sptd.DataBuffer		= pData;
    sptdwb.sptd.SenseInfoOffset = offsetof(SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER,ucSenseBuf);
    sptdwb.sptd.Cdb[0]			= CMD_READ;
	
    length = sizeof(SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER);
    status = DeviceIoControl(hUDisk,
		IOCTL_SCSI_PASS_THROUGH_DIRECT,
		&sptdwb,
		length,
		&sptdwb,
		length,
		(ULONG *)pnLength,
		FALSE);//1-OK
	*pnLength=sptdwb.sptd.DataTransferLength;
	
	if(status)//OK
		return PS_OK;
	return PS_COMM_ERR;
}
int UDiskGetImage(HANDLE hHandle,BYTE* pBuf,ULONG lLen)
{
	ULONG lTmpLen=lLen;
	lTmpLen=lLen/2;
	if(UDiskRevData(hHandle,pBuf,&lTmpLen)!=PS_OK)
		return PS_COMM_ERR;
	return UDiskRevData(hHandle,pBuf+lTmpLen,&lTmpLen);//*/
}
int UDiskDownImage(HANDLE hHandle,BYTE* pBuf,ULONG lLen)
{
	ULONG lTmpLen;
	lTmpLen=lLen/2;
	if(UDiskSendData(hHandle,pBuf,lTmpLen)!=PS_OK)
		return PS_COMM_ERR;
	return UDiskSendData(hHandle,pBuf+lTmpLen,lTmpLen);
}