#if !defined(AFX_DLGMSG_H__0E444F80_4E9B_44D5_99F5_4F851538ADCB__INCLUDED_)
#define AFX_DLGMSG_H__0E444F80_4E9B_44D5_99F5_4F851538ADCB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgMsg.h : header file
//

#define IDD_DLGMSG                      1000
#define IDC_EDIT1                       1000
/////////////////////////////////////////////////////////////////////////////
// CDlgMsg dialog

class CDlgMsg : public CDialog
{
// Construction
public:
	CDlgMsg(CString str="",CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgMsg)
	enum { IDD = IDD_DLGMSG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

public:
	CString m_msg;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgMsg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgMsg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGMSG_H__0E444F80_4E9B_44D5_99F5_4F851538ADCB__INCLUDED_)
