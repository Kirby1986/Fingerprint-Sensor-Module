#ifndef _DEVICE_H_
#define _DEVICE_H_
#include <string>
using namespace std;

////////////////////////////////////////////////////////////////////
extern int       g_nComPort     ; //���ں�
extern int       g_nBaudRate    ; //������
extern HANDLE    g_hCom         ; //���ھ��
////////////////////////////////////////////////////////////////////
#define DEVICE_USB		0
#define DEVICE_COM		1
#define DEVICE_UDisk	2

typedef struct _tDevHandle
{
	int    nDeviceType;	//�豸���ͣ�DEVICE_USB��ʽ������DEVICE_COM��ʽ����������ʽDEVICE_UDisk
	int    nPackSize;	//����С 32,64,128,256
    HANDLE hDevice;
	HANDLE hUSBWrite;
	HANDLE hUSBRead; 
}tDevHandle,*PtDevHandle;

int WINAPI OpenDeviceEx(HANDLE* pHandle, int nDeviceType,int iCom,int iBaud,int nPackageSize=2,int iDevNum=0);
int WINAPI CloseDeviceEx(HANDLE hHandle);
int WINAPI OpenCOMEx(HANDLE* pHandle,int comPort, int baudRate, int PackSize=128);//COM	(1)
int WINAPI CloseCOMEx(HANDLE hHandle);
int WINAPI OpenUSBEx(HANDLE* pHandle,UINT nDevNum=0, int PackSize=128);//USB	(0)
int WINAPI CloseUSBEx(HANDLE hHandle);
int WINAPI OpenUDiskEx(HANDLE* pHandle,int nDevNum=0,int PackSize=128);//UDidk	(2)
int WINAPI CloseUDiskEx(HANDLE hHandle);

int JudgeDisk(HANDLE hUDev);//use for UDisk
DWORD GetUSNDevNums();	//use for USB	; FG_USB �豸��
DWORD GetUDiskNums();	//use for UDisk	; UDisk  �豸��
HANDLE OpenUSBfileEx(char* sDevName,char* sFileName=NULL);//use for USB
int GetDevType(HANDLE hHandle);
int GetDevPacketSize(HANDLE hHandle);
int SetDevPacketSize(HANDLE hHandle=NULL,int PackSize=128);

//USBͨѶ
int USBDownData(HANDLE hHandle,unsigned char *image,int nLen);
int USBDownData1(HANDLE hHandle,unsigned char *image,int nLen);
int USBGetData(HANDLE hHandle,unsigned char* DataBuf,int nLen,int Timeout = 2000);
int USBGetImage(HANDLE hHandle,unsigned char* DataBuf,int nLen);
int USBDownImage(HANDLE hHandle,unsigned char *image,int nLen);

//����ͨѶ
BOOL WINAPI	GetByte(HANDLE hCom,unsigned char* tranChar);
BOOL WINAPI	SendByte(HANDLE hCom,unsigned char tranChar);

//UDiskͨѶ
int UDiskSendData(HANDLE hHandle, BYTE* pData,ULONG nLength,INT nTimeOut=2000);
int UDiskRevData(HANDLE hHandle, BYTE* pData,ULONG* pnLength,INT nTimeout=2000);
int UDiskGetImage(HANDLE hHandle,BYTE* pBuf,ULONG lLen);
int UDiskDownImage(HANDLE hHandle,BYTE* pBuf,ULONG lLen);
////////////////////////////////////////////////////////////////////
#define		F32x_SUCCESS				0x00
#define		F32x_DEVICE_NOT_FOUND		0xFF
#define		F32x_INVALID_HANDLE			0x01
#define		F32x_READ_ERROR				0x02
#define		F32x_RX_QUEUE_NOT_READY		0x03
#define		F32x_WRITE_ERROR			0x04
#define		F32x_RESET_ERROR			0x05
#define		F32x_INVALID_PARAMETER		0x06
#define		F32x_INVALID_REQUEST_LENGTH	0x07
#define		F32x_DEVICE_IO_FAILED		0x08
#define     F32x_EVENT_ERROR            0x09
#define     F32x_TIME_OUT               0x10
#define     F32x_REV_PACK_ERROR         0x11    //�յ������ݰ�����

// Buffer size limits
#define		F32x_MAX_DEVICE_STRLEN		256
#define		F32x_MAX_READ_SIZE			64*1024//4096
#define		F32x_MAX_WRITE_SIZE			64*1024//4096

static DWORD	sgdwNumDevices = 0;
static DWORD	sgdwWriteTimeout = 100;
static DWORD	sgdwReadTimeout = 100;

int F32x_Read(HANDLE cyHandle, LPVOID lpBuffer, DWORD dwBytesToRead, LPDWORD lpdwBytesReturned);
int F32x_Write(HANDLE cyHandle, LPVOID lpBuffer, DWORD dwBytesToWrite, LPDWORD lpdwBytesWritten);
static BOOL ValidParam(LPDWORD lpdwPointer);
static BOOL ValidParam(LPVOID lpVoidPointer, LPDWORD lpdwPointer); 
static BOOL ValidParam(LPDWORD lpdwPointer1, LPDWORD lpdwPointer2);

int DeviceRead(HANDLE hUSBRead,BYTE* buffer, DWORD dwSize, DWORD* lpdwBytesRead);
int DeviceWrite(HANDLE hUSBWrite,BYTE* buffer, DWORD dwSize, DWORD* lpdwBytesWritten);

#endif